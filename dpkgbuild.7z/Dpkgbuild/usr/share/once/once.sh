#!/bin/bash
set -euo pipefail

log="/var/log/error.once.log"
exec > >(tee -a "$log") 2>&1

if [ "$EUID" -ne 0 ]; then
  echo "please run as root"
  exit 1
fi

if grep -q "boot=live" /proc/cmdline || [ -f /run/live/medium/live.cfg ]; then
  echo "error.os live environment"
  exit 0
fi

echo "detecting cpu vendor..."
vendor=$(grep 'vendor_id' /proc/cpuinfo | head -1 | awk '{print $3}')
echo "cpu vendor: $vendor"

if [ "$vendor" = "GenuineIntel" ]; then
  echo "removing amd kernel modules..."
  rm -rf /lib/modules/*/kernel/drivers/cpufreq/amd*
  rm -rf /lib/modules/*/kernel/drivers/platform/x86/amd*
  rm -rf /lib/modules/*/kernel/drivers/firmware/amd*

  echo "purging amd packages..."
  apt-get purge -y \
    amd64-microcode \
    xserver-xorg-video-amdgpu \
    xserver-xorg-video-ati \
    xserver-xorg-video-radeon \
    mesa-vulkan-radeon \
    firmware-amd-graphics

elif [ "$vendor" = "AuthenticAMD" ]; then
  echo "removing intel kernel modules..."
  rm -rf /lib/modules/*/kernel/drivers/cpufreq/intel*
  rm -rf /lib/modules/*/kernel/drivers/platform/x86/intel*
  rm -rf /lib/modules/*/kernel/drivers/firmware/intel*

  echo "purging intel packages..."
  apt-get purge -y \
    intel-microcode \
    xserver-xorg-video-intel \
    mesa-vulkan-intel \
    firmware-iwlwifi \
    firmware-misc-nonfree

else
  echo "unknown vendor — skipping removal"
fi

echo "removal complete."
touch /var/lib/error.once.complete

if command -v systemctl >/dev/null; then
  systemctl disable once.service || true
  rm -f /etc/systemd/system/once.service
  systemctl daemon-reexec
  systemctl daemon-reload
fi

rm -f /usr/share/once/once.sh
